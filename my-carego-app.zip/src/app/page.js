import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import AboutRobot from "@/components/AboutRobot";
import Features from "@/components/Features";
import Specs from "@/components/Specs";
import PatientMonitor from "@/components/PatientMonitor";
import Team from "@/components/Team";
import Booking from "@/components/Booking";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main className="min-h-screen bg-[#fcfcff] selection:bg-purple-100 selection:text-purple-900">
      <Navbar />
      <Hero />
      {/* <AboutRobot /> */}
      <Features />
      <Specs />
      <PatientMonitor />
      <Team />
      <Booking />
      <Footer />
    </main>
  );
}