"use client";
import { motion } from "framer-motion";

const marketingFeatures = [
  { 
    title: "Zero-Contact Safety", 
    desc: "Eliminates cross-contamination by handling routine checks automatically, reducing medical staff exposure risks by up to 90%.", 
    size: "col-span-2", 
    icon: "🛡️" 
  },
  { 
    title: "Real-Time Bio-Link", 
    desc: "Continuous, non-stop vital telemetry (SpO2, HR, Temp) streamed straight to clinician dashboards.", 
    size: "col-span-1", 
    icon: "📊" 
  },
  { 
    title: "AI-Verified Dispensing", 
    desc: "Utilizes MobileNetV2 facial recognition to ensure medications and supplies are only delivered to verified patients.", 
    size: "col-span-1", 
    icon: "🧠" 
  },
  { 
    title: "Telemedicine Window", 
    desc: "Integrated two-way audio and live video streams connect isolated patients with doctors and families seamlessly.", 
    size: "col-span-2", 
    icon: "💬" 
  },
];

export default function Features() {
  return (
    <section id="capabilities" className="py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-20">
          <h2 className="text-5xl font-black tracking-tighter text-slate-900">
            Why Choose <span className="text-purple-600 italic">CareGo</span>?
          </h2>
          <p className="text-slate-400 mt-4 font-medium uppercase tracking-[0.3em] text-xs">
            Redefining Quarantine Operations with Automation
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {marketingFeatures.map((f, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className={`${f.size} group p-10 rounded-[3rem] bg-slate-50 border border-slate-100 hover:bg-white hover:shadow-2xl hover:shadow-purple-100 transition-all cursor-default`}
            >
              <div className="text-4xl mb-6 group-hover:scale-110 transition-transform origin-left">{f.icon}</div>
              <h3 className="text-xl font-black text-slate-900 mb-2">{f.title}</h3>
              <p className="text-slate-500 font-medium leading-relaxed text-sm">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}