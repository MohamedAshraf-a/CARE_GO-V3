"use client";
import Image from "next/image";
import { motion } from "framer-motion";

export default function Team() {
  const members = [
    { name: "Mohamed Ashraf Gaber", role: "FRONT END", image: "/team/1.png" },
    { name: "Abdelrahman Essam Ibrahim", role: "Embedded Systems ", image: "/team/2.png" },
    { name: "Abdelrahman Magdy Abdallah", role: "IoT & Wireless Specialist", image: "/team/3.png" },
    { name: "Abdelrahman Atef Elameay", role: "AI", image: "/team/4.png" },
    { name: "Ahmed Mahmoud Rady", role: "Hardware Architect", image: "/team/5.png" },
    { name: "Esam Hisham Elsaid", role: "Computer Vision Engineer", image: "/team/6.png" },
    { name: "Mahmoud Ezzat Elsayed", role: "Mechanical Design Lead", image: "/team/7.png" },
    { name: "Mohamed Ezzat Morshady", role: "Cloud Systems Integration", image: "/team/8.png" },
    { name: "Mohamed Sherif Ramzy", role: "Biomedical Systems Engineer", image: "/team/9.png" },
    { name: "Youssef Mohamed El Sayed", role: "Firmware Engineer", image: "/team/10.png" },
  ];

  return (
    <section id="team" className="py-32 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-5xl md:text-6xl font-black tracking-tight text-slate-900"
          >
            Project <span className="text-purple-600 italic">Engineers</span>
          </motion.h2>

          <p className="mt-5 text-slate-400 uppercase tracking-[0.4em] text-xs font-bold">
            CareGo Graduation Project Class of 2026
          </p>
          <p className="mt-2 text-slate-500 font-medium text-sm">
            Under the Supervision of <span className="text-slate-900 font-bold">Dr. Aly Abd Rabou Aly Daby</span>
          </p>
        </div>

        {/* 2x5 Balanced Responsive Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 lg:gap-8">
          {members.map((member, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
              whileHover={{ y: -8 }}
              className="group relative overflow-hidden rounded-[32px] bg-white shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_20px_40px_rgb(168,85,247,0.15)] border border-slate-100 transition-all duration-500 flex flex-col"
            >
              <div className="relative h-[260px] w-full overflow-hidden bg-slate-100">
                {/* Simulated default image shelf if asset is missing */}
                <div className="absolute inset-0 flex items-center justify-center text-4xl bg-slate-100 text-slate-300 group-hover:scale-105 transition-transform duration-500">
                  👤
                </div>
                {member.image && (
                  <Image
                    src={member.image}
                    alt={member.name}
                    fill
                    className="object-cover object-top transition-transform duration-700 ease-out group-hover:scale-105 z-10"
                  />
                )}
                <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-slate-900/80 via-slate-900/40 to-transparent z-20" />
              </div>

              <div className="p-6 flex-grow flex flex-col justify-between relative z-30 bg-white">
                <div>
                  <h3 className="text-sm font-black text-slate-900 tracking-tight line-clamp-2 group-hover:text-purple-600 transition-colors">
                    {member.name}
                  </h3>
                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mt-1">
                    {member.role}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}