"use client";

export default function Booking() {
  return (
    <section className="py-32 bg-slate-50">
      <div className="max-w-3xl mx-auto px-6 bg-white p-16 rounded-[4rem] shadow-2xl border border-slate-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-600/5 rounded-full -mr-16 -mt-16" />
        
        <div className="text-center mb-12">
          <h2 className="text-5xl font-black text-slate-900 tracking-tighter">Join the Priority List</h2>
          <p className="text-purple-600 mt-4 font-bold uppercase tracking-widest text-[10px]">
            Institutional Pilot Deployment Q4 2026
          </p>
        </div>

        <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
          <div className="grid md:grid-cols-2 gap-6">
            <input 
              type="text" 
              placeholder="Hospital / Organization Name" 
              className="w-full px-6 py-4 bg-slate-50 rounded-2xl border border-slate-100 focus:ring-2 focus:ring-purple-600 transition-all outline-none text-slate-800 font-medium text-sm" 
            />
            <input 
              type="text" 
              placeholder="Department (e.g., Isolation Ward)" 
              className="w-full px-6 py-4 bg-slate-50 rounded-2xl border border-slate-100 focus:ring-2 focus:ring-purple-600 transition-all outline-none text-slate-800 font-medium text-sm" 
            />
          </div>
          <input 
            type="email" 
            placeholder="Official Medical Email Address" 
            className="w-full px-6 py-4 bg-slate-50 rounded-2xl border border-slate-100 focus:ring-2 focus:ring-purple-600 transition-all outline-none text-slate-800 font-medium text-sm" 
          />
          <button className="w-full bg-slate-900 hover:bg-purple-600 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-xs transition-all active:scale-95 shadow-xl hover:shadow-purple-200">
            Request Institutional Access
          </button>
        </form>
      </div>
    </section>
  );
}