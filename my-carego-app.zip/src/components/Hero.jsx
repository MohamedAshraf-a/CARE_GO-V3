"use client";

import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="min-h-screen flex items-center justify-center text-center px-6">

      <div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-6xl font-bold text-purple-700"
        >
          AI-Powered Medical Care Robot
        </motion.h1>

        <p className="mt-6 text-xl text-slate-600 max-w-3xl">
          Intelligent Healthcare Robotics for Safer
          Quarantine Environments
        </p>

      </div>

    </section>
  );
}